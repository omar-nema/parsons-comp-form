var dataTable;
var barWidth, originX, originY, padding;

function preload() {
    dataTable = loadTable('./data.csv', 'csv', 'header').rows;
}

function dataPrep(){
    originX = 30;
    originY = height - 50;
    padding = 15;
    barWidth = (width*.95) / (dataTable.length) - padding;

    yvals = dataTable.map(d => parseInt(d.obj.y));
    ymax = Math.max(...yvals);  
    heightunit = height*.8/ymax;

    dataTable.forEach(function(d, i){
        d.obj.xval = originX+(i*(barWidth+padding));
        d.obj.heightval = (d.obj.y)*heightunit;
    })
}

function setup() {
    // put setup code here - one time. no need 2 call
    createCanvas(700, 400)
    dataPrep();
    noLoop();
    fill('black');
   
}

function draw() {
    background('#fafafa')
    rectWidth = 50;
    fill('blue')
    textAlign(CENTER, CENTER);
    textSize(24);
    text('Dessert Ratings',width/2, 50)
    
    dataTable.forEach(function(d, i){
        console.log(d)
        fill('gray')
        rect(d.obj.xval, originY, barWidth, -d.obj.heightval);
        fill('black')
        textSize(12)
        text(d.obj.type, d.obj.xval+barWidth/2, originY+20)
    })


}

//stuff outside is exec first tho you don't do that w p5 usually