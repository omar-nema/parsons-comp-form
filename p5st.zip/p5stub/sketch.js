

function preload() {

}


function setup() {
    createCanvas(700, 700)   
}

function draw() {

}
